# Security Policy

## Reporting a Vulnerability?
Where to contact me if you find a Vulnerability and Vulnerability Fix.

## Contact: 
empty@empty.com (Coming Soon)

## Vulnerabilitys List

--- Vulnerability0 ---

**Name- Access To Pages Login Password (Vulnerability)**

### Impact
It gives you access to get the password, to access **"About_Me_Page-Login.html, Other_Important_Stuff_Page-Login.html, Videos_Page-Login.html and Pictures_Page-Login.html".** 

### Patches
The vulnerability is not patched. You should not be scared, you should abuse it (lol). If you see this as a threat, then you should access the site with Tor Browser (https://www.torproject.org/download/) **(Tor Browser is also OPEN SOURCED** (https://www.torproject.org/download/tor/)**.**

### Workarounds
Access the site with Tor Browser (https://www.torproject.org/download/) **(Tor Browser is also OPEN SOURCED** (https://www.torproject.org/download/tor/)**.**  if you feel like it will affect you in any negative way. 

### References
The Vulnerability In Action (Video): (https://tpt-website.github.io/vulnerabilitys-found/Vulnerability0.mp4)

### For more information 
* Open An Issue In Email: (empty@empty.com) (COMING SOON)
* Email Us At: (empty@empty.com) (COMING SOON)
